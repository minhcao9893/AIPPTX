@echo off
title AI-PPTX Generator
echo ============================================
echo   AI-PPTX - Khoi dong he thong...
echo ============================================
echo.

REM Go to the project root folder (same folder as this .bat file)
cd /d "%~dp0"

REM Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [LOI] Khong tim thay Python!
    echo Vui long cai dat Python 3.10+ tu https://python.org
    pause
    exit /b 1
)

REM Auto-install requirements
echo [1/3] Kiem tra va cai packages...
pip install -r requirements.txt -q --disable-pip-version-check
if errorlevel 1 (
    echo [LOI] Cai dat packages that bai. Kiem tra ket noi mang.
    pause
    exit /b 1
)

REM Clear Python cache to avoid stale code
echo [2/3] Xoa cache...
if exist app\__pycache__ rmdir /s /q app\__pycache__
if exist app\modules\__pycache__ rmdir /s /q app\modules\__pycache__
if exist __pycache__ rmdir /s /q __pycache__

echo [3/3] Khoi dong Web UI...
echo.
echo Trinh duyet se tu dong mo tai: http://localhost:5000
echo De dung chuong trinh: nhan Ctrl+C roi dong cua so nay.
echo.
python -m app.app

pause
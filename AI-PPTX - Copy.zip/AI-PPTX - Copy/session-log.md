## [2026-04-24] Upgrade Step2 Preview: render content/bang thuc te
STATUS: ⚠️cần-test
DID:
  step2_init.js: fetch /api/parse-slides-full song song voi /api/parse-slides
    Luu ket qua vao window._slideFullData[slideIndex]
  step2_preview.js: viet lai toan bo _render() dung data thuc
    - Title thuc, type-aware: table/bullet/text
    - _renderTable(): header row + data rows thuc co ellipsis
    - _renderBullets(): accent dot + text thuc
    - Status bar hien Slide N + type
  step2_slides.js: selectSlide() -> Preview.onDesignChange() khi doi slide
GOTCHA:
  window._slideFullData key la slide.index (1-based, khong phai 0-based)
  Preview.onDesignChange() co guard _isOpen nen goi o dau cung an toan
NEXT:
  1. Restart RUN.bat -> vao Step 2 -> mo Preview
  2. Slide co bang: thay header + data rows thuc (khong con placeholder)
  3. Click doi slide: Preview re-render dung noi dung tuong ung
FILES: app/ui_modules/step2_preview.js, app/ui_modules/step2_init.js, app/ui_modules/step2_slides.js

## [2026-04-24] Upgrade Step1 Preview: render Slide Cards voi Content + Bang
STATUS: ⚠️cần-test
DID:
  key_pool.py: thêm mark_bad(key) + next_key() bỏ qua bad keys
  input_ai_splitter.py _call_ai: catch 400+restricted → pool.mark_bad(key) → retry
  stage1_list_updater.py _call_groq_json: tương tự + max(max_retries, len(pool)) để thử hết pool
GOTCHA:
  - mark_bad chỉ tồn tại trong session (in-memory), restart app → reset (OK - key có thể được restore)
  - _POOL singleton: force_reload=True trong stage1 để đảm bảo cùng object
  - Nếu TẤT CẢ keys bị restrict → graceful skip (không crash)
NEXT:
  1. Restart RUN.bat → chạy lại → terminal phải hiện: key ***xxxx bị loại. Còn N/M key
  2. Stage 1 phải chạy tiếp trên key tốt → không còn lỗi restrict
FILES: app/key_pool.py, app/modules/input_ai_splitter.py, app/stage1_list_updater.py

STATUS: ⚠️cần-test
DID:
  input_ai_splitter.py — 3 fix:
  1. STAGE2_PROMPT: thêm ví dụ output rõ ràng + nhấn mạnh BẮT BUỘC dùng {Slide N} dấu ngoặc nhọn
  2. _run_stage1 JSON parse: strip markdown fences + dùng regex \{[\s\S]*?\} thay vì [^{}]
  3. Validate sau Stage2: nếu AI không trả {Slide N} → retry với reminder → fallback wrapper
GOTCHA:
  - Root cause: llama/groq hay dùng ## Slide 1 thay {Slide 1} → slide_count = 0
  - Fallback cuối cùng: {Slide 1} Nội dung\n + ai_response để không bao giờ trả 0 slide
NEXT:
  1. Restart RUN.bat → chọn file Word → Mode AI → nhấn Phân tích bằng AI
  2. Kiểm tra: slide_count > 0, toast hiện số slide + stage1 info
  3. Nếu vẫn 0 → đọc terminal RUN.bat xem AI trả format gì
FILES: app/modules/input_ai_splitter.py

## [2026-04-24] Mode 2 AI — nâng cấp 2-lượt (Stage1 + Stage2)
STATUS: ✅done
DID:
  input_ai_splitter.py: refactor split_docx_with_ai() thành 2-lượt:
    Lượt 1: strip_numbers(raw_text) → AI extract blacklist/whitelist → merge + save async
    Lượt 2: mask(raw_text_có_số, blacklist=new) → AI soạn {Slide N}/{Chart} → unmask
    STAGE1_PROMPT (JSON output) + STAGE2_PROMPT (giữ alias + số) — 2 prompt riêng biệt
  routes_input.py: /api/ai-split-docx trả thêm stage1_added_w, stage1_added_b
  step1_input.js: runAIAnalysis() dùng data.trigger_text, progress 6-bước, toảt Stage1 info
GOTCHA:
  - list_store.py chỉ có load_lists() trả (whitelist, blacklist) — không có get_blacklist() riêng
  - _run_stage1 graceful: nếu AI lỗi → dùng lists cũ, không crash luồng
  - STAGE1_PROMPT yêu cầu JSON thuần, parse với regex fallback
NEXT:
  1. Restart RUN.bat → chọn file Word dài → chỉnh Mode [AI phân tích] → nhấn Phân tích
  2. Kiểm tra progress UI: 6 bước hiện đúng thứ tự
  3. Toast cuối: số slide + (+X blacklist, +Y whitelist)
  4. Nếu Stage 1 lỗi: phải vẫn chạy được (graceful), chỉ có cảnh báo stderr
  5. Nếu OK → đi tiếp bước edit preview + sang Step 2
FILES: app/modules/input_ai_splitter.py, app/modules/routes_input.py, app/ui_modules/step1_input.js

STATUS: ⚠️cần-test
DID:
  app.py: đổi verbose=False → verbose=True khi gọi run_stage1_update()
  app.py: bắt exception Stage 1 → in traceback đầy đủ ra stderr + ghi vào pipeline_debug.log
  Phát hiện: pipeline_debug.log không có section [Stage1] → Stage 1 fail silent hoàn toàn
  Nguyên nhân nghi: import error, config error, hoặc exception trước _dlog
GOTCHA:
  - verbose=False che hết exception của Stage 1 → khó debug
  - print() Stage 1 hiện trong terminal RUN.bat, KHÔNG hiện trên web UI
  - Web UI chỉ hiện message từ _update() (API /api/progress)
NEXT:
  1. Restart RUN.bat → chạy pipeline 1 lần
  2. Xem terminal RUN.bat: tìm 🧠 [Stage 1] hoặc ⚠️ Stage 1 failed + traceback
  3. Xem pipeline_debug.log: tìm [STAGE1 — EXCEPTION] hoặc [STAGE1 — Text gửi AI]
  4. Paste traceback để fix tiếp nếu có lỗi
FILES: app/app.py

STATUS: ⚠️can-test
DID:
  sanitizer_core.py: fix mask_value() — classify toàn chuỗi chỉ khi ≤ 5 words
    Bug: ORG_SUFFIXES.search() match "công ty Pokemon" bên trong title dài
         → toàn bộ chuỗi "Báo cáo Hiệu suất..." bị alias thành Company-A/B
    Fix: chỉ classify-toàn-chuỗi khi len(words) <= 5
         Chuỗi dài → bỏ qua classify, để ORG_SUFFIXES.sub() xử lý inline như cũ
  Vấn đề phụ: Stage 1 log không xuất hiện → chưa rõ Stage 1 có chạy không
GOTCHA:
  - Whitelist/Blacklist = [] → Stage 1 fail silent hoặc chưa inject _dlog
  - Cần kiểm tra stage1_list_updater.py có _dlog chưa
NEXT:
  1. Restart RUN.bat → chạy lại pipeline
  2. Kiểm tra pipeline_debug.log:
     - Phải có section [Stage1] (nếu không → Stage 1 vẫn fail)
     - Company-A/B phải map tên ngắn (Pokemon, tên người...) thay vì cả câu dài
     - Whitelist/Blacklist vẫn = 0 → cần debug app.py flow truyền params
  3. Nếu Stage 1 vẫn không log → đọc stage1_list_updater.py tìm _dlog injection
FILES: app/modules/sanitizer_core.py

STATUS: ✅done
DID:
  ai_planner_core.py: inject 3 _dlog() calls vào plan_layout()
    - Sau _plan_parallel(): _dlog("AI PLANNER — PARALLEL", n_slides + layout_plan[:2000])
    - Sau prompt build (SEQUENTIAL): _dlog("AI PLANNER — SEQUENTIAL PROMPT", prompt[:2000])
    - Sau raw_response (SEQUENTIAL): _dlog("AI PLANNER — SEQUENTIAL RESPONSE", raw_response[:3000])
  File đã có sẵn _dlog() function + imports (datetime, Path) từ session trước
  pipeline_debug.log xuất tại AI-PPTX/ root — ghi append mỗi lần chạy pipeline
GOTCHA:
  - _dlog() đã tồn tại trong file, chỉ thiếu call-sites → patch nhẹ, không thêm code mới
  - 3 file khác (stage1_list_updater.py, sanitizer_core.py) đã inject xong session trước
NEXT:
  Restart RUN.bat → chạy pipeline 1 lần → mở AI-PPTX/pipeline_debug.log kiểm tra:
    - Phải thấy section [Stage1], [Sanitizer], [AI PLANNER — PARALLEL/SEQUENTIAL]
    - Nếu log rỗng → check path _DEBUG_LOG (parent.parent.parent từ app/modules/)
FILES: app/modules/ai_planner_core.py

## [2026-04-23] Stage 1 → pipeline hot-path: classify + sanitize trong 1 lần chạy
STATUS: ⚠️cần-test
DID:
  stage1_list_updater.py:
    - import threading
    - run_stage1_update() đổi return type: Tuple[int,int] → Tuple[int,int,List[str],List[str]]
    - load_lists() chuyển lên đầu hàm (để trả về dù text rỗng / API fail)
    - save_lists() bọc trong threading.Thread(daemon=True) — không block pipeline
  sanitizer_core.py:
    - sanitize() nhận optional whitelist/blacklist params
    - Nếu được truyền: dùng luôn (không gọi load_lists lại)
    - Nếu None: fallback load_lists() như cũ (backward compatible)
  app.py — _run_pipeline():
    - Stage 1 unpack 4 giá trị: _n_w, _n_b, _s1_whitelist, _s1_blacklist
    - Stage 1 fail → _s1_whitelist/_s1_blacklist = None, sanitize() tự fallback
    - sanitize() nhận whitelist=_s1_whitelist, blacklist=_s1_blacklist
GOTCHA:
  - sanitizer.py (thin wrapper) đã được forward params trong session này — OK
  - Stage 1 fail: _s1_whitelist=None → sanitize() tự fallback load_lists — safe
NEXT:
  1. Kiểm tra app/sanitizer.py: nếu nó wrap sanitize() riêng thì thêm **kwargs hoặc forward params
  2. Restart RUN.bat → Pick file Word → check progress UI:
     - "✅ Stage 1: +X whitelist, +Y blacklist"
     - "✅ Đã mask Z tên" (dùng blacklist mới từ Stage 1)
  3. Kiểm tra console không có đường dẫn tuple unpack error
FILES: app/stage1_list_updater.py, app/modules/sanitizer_core.py, app/app.py

## [2026-04-23] Stage 1 integration — auto key rotation khi pick file
STATUS: ⚠️cần-test
DID:
  stage1_list_updater.py: refactor hoàn toàn
    - Bỏ _collect_input_text() scan folder cũ
    - Thêm _extract_text_from_data(raw_data) lấy text từ data đã parse
    - _call_groq_json(): thêm _is_retryable_error() detect 429/restricted/timeout
    - Auto key rotation: ghi stderr + continue sang key tiếp (force_reload=True)
    - Nếu tất cả keys fail → return None → run_stage1_update trả (0,0), không crash
    - Thêm Stage1Error, Stage1ApiError, Stage1ConfigError exceptions
    - run_stage1_update(raw_data, ...) — signature mới, nhận raw_data thay vì scan folder
  app.py: 2 thay đổi
    - _run_pipeline(): thêm Stage 1 ngay sau Step 1 (parse), trước Step 2 (sanitize)

@echo off
title AIPPTX - KET NOI GITHUB LAN DAU
setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1

set "BASE=%~dp0"
if "%BASE:~-1%"=="\" set "BASE=%BASE:~0,-1%"

cls
echo ===================================================
echo   AIPPTX - KET NOI GITHUB LAN DAU
echo ===================================================
echo.

set "MY_GIT="
if exist "%BASE%\GitPortable\cmd\git.exe" (
    set "MY_GIT=%BASE%\GitPortable\cmd\git.exe"
    echo [OK] Git Portable.
) else (
    git --version >nul 2>&1
    if not errorlevel 1 (
        set "MY_GIT=git"
        echo [OK] Git Global.
    )
)

if "!MY_GIT!"=="" (
    echo [LOI] Khong tim thay Git!
    echo       - May nha  : cai Git tai git-scm.com
    echo       - May cty  : dat GitPortable vao "%BASE%\GitPortable\"
    pause
    exit /b 1
)

for /f "delims=" %%v in ('"!MY_GIT!" --version 2^>^&1') do echo [OK] %%v

if exist "%BASE%\.git" (
    echo.
    echo [OK] Da co .git - khong can setup lai.
    echo      Dung 0_DONG_BO_GITHUB.bat de tiep tuc.
    pause
    exit /b 0
)

echo.
echo Chua co .git - bat dau setup (chi lam 1 lan).
echo.
set /p my_name="1. Ten hien thi tren GitHub: "
set /p my_email="2. Email GitHub: "
set /p git_link="3. Link repo (VD: https://github.com/user/AIDIP.git): "

if "!my_name!"=="" ( echo [LOI] Ten trong. & pause & exit /b 1 )
if "!my_email!"=="" ( echo [LOI] Email trong. & pause & exit /b 1 )
if "!git_link!"=="" ( echo [LOI] Link repo trong. & pause & exit /b 1 )

echo.
"!MY_GIT!" init
if errorlevel 1 ( echo [LOI] git init that bai. & pause & exit /b 1 )
echo [OK] git init.

"!MY_GIT!" config --global user.name "!my_name!"
"!MY_GIT!" config --global user.email "!my_email!"
"!MY_GIT!" config --global credential.helper store
echo [OK] Da luu user config.

"!MY_GIT!" remote add origin !git_link! 2>nul
if errorlevel 1 "!MY_GIT!" remote set-url origin !git_link!
echo [OK] Remote: !git_link!

echo.
echo [*] Pull du lieu tu GitHub...
echo     (Co the hoi dang nhap - nhap username + PAT token)
echo.
"!MY_GIT!" pull origin main --allow-unrelated-histories
if errorlevel 1 (
    echo [WARN] Pull gap loi - neu repo con trong thi binh thuong.
)

echo.
echo ===================================================
echo [OK] SETUP HOAN TAT!
echo   1. Chay 2_SETUP_ENV.bat     - cai thu vien
echo   2. Chay 3_START_PROJECT.bat - chay project
echo   3. Chay 0_DONG_BO_GITHUB.bat- bat dau dong bo
echo ===================================================
pause
endlocal

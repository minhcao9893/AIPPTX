@echo off
title AIDIP - DONG BO GITHUB (AUTO 15 PHUT)
setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1

set "BASE=%~dp0"
if "%BASE:~-1%"=="\" set "BASE=%BASE:~0,-1%"

:: ===================================================
:: PHAT HIEN GIT
:: ===================================================
set "MY_GIT="
if exist "%BASE%\GitPortable\cmd\git.exe" (
    set "MY_GIT=%BASE%\GitPortable\cmd\git.exe"
) else (
    git --version >nul 2>&1
    if not errorlevel 1 set "MY_GIT=git"
)

if "!MY_GIT!"=="" (
    echo [LOI] Khong tim thay Git!
    echo       - May nha  : Git da cai toan cuc
    echo       - May cty  : dat GitPortable vao "%BASE%\GitPortable\"
    pause
    exit /b 1
)
echo [OK] Git: !MY_GIT!

:: ===================================================
:: KIEM TRA .git
:: ===================================================
if not exist "%BASE%\.git" (
    echo [LOI] Chua co .git - chay 1_SETUP_GITHUB.bat truoc!
    pause
    exit /b 1
)

cd /d "%BASE%"

:: ===================================================
:: DON DET TRANG THAI (chay 1 lan truoc loop)
:: ===================================================
if exist "%BASE%\.git\rebase-merge" "!MY_GIT!" rebase --abort >nul 2>&1
if exist "%BASE%\.git\rebase-apply" "!MY_GIT!" rebase --abort >nul 2>&1

for /f "delims=" %%b in ('"!MY_GIT!" rev-parse --abbrev-ref HEAD 2^>nul') do set "CUR_BRANCH=%%b"
if "!CUR_BRANCH!"=="HEAD" (
    echo [!] Detached HEAD - chuyen ve main...
    "!MY_GIT!" checkout main 2>nul || "!MY_GIT!" checkout -b main 2>nul
)
if not "!CUR_BRANCH!"=="main" (
    "!MY_GIT!" checkout main 2>nul
)
echo [OK] Branch: main
echo.

:: ===================================================
:: LOOP DONG BO
:: ===================================================
:loop
cls
echo ===================================================
echo   AIDIP - TU DONG DONG BO GITHUB (MOI 15 PHUT)
echo   Git : !MY_GIT!
echo   Thu : %date% %time%
echo ===================================================
echo.

cd /d "%BASE%"

"!MY_GIT!" add .

"!MY_GIT!" diff --cached --quiet 2>nul
if errorlevel 1 (
    "!MY_GIT!" commit -m "Auto-sync %date% %time%"
) else (
    echo      Khong co thay doi moi.
)

if exist "%BASE%\.git\rebase-merge" "!MY_GIT!" rebase --abort >nul 2>&1
if exist "%BASE%\.git\rebase-apply" "!MY_GIT!" rebase --abort >nul 2>&1

"!MY_GIT!" pull --no-rebase origin main
if errorlevel 1 (
    "!MY_GIT!" fetch origin main
    "!MY_GIT!" merge origin/main --no-edit
)

"!MY_GIT!" push origin main
if errorlevel 1 echo [!] Push gap loi - kiem tra ket noi mang hoac token GitHub.

echo.
echo [%time%] Dong bo xong! Cho 15 phut... (Ctrl+C de dung)
echo.
timeout /t 900 /nobreak
goto loop
